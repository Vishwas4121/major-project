let animationId;
let animZoom = 300;

function generateFractal() {
  cancelAnimationFrame(animationId);
  const canvas = document.getElementById('fractalCanvas');
  const ctx = canvas.getContext('2d');
  const zoom = parseFloat(document.getElementById('zoom').value);
  const iterations = parseInt(document.getElementById('iterations').value);
  const type = document.getElementById('fractalType').value;
  const colorScheme = document.getElementById('colorScheme').value;
  const juliaConst = document.getElementById('juliaConst').value.split(/[+i]/).map(Number);

  const width = canvas.width;
  const height = canvas.height;
  const cx = juliaConst[0] || -0.7;
  const cy = juliaConst[1] || 0.27015;
  const image = ctx.createImageData(width, height);

  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let zx = 1.5 * (x - width / 2) / (0.5 * zoom * width);
      let zy = (y - height / 2) / (0.5 * zoom * height);
      let i = iterations;
      let zx0 = zx, zy0 = zy;

      while (zx * zx + zy * zy < 4 && i > 0) {
        const tmp = zx * zx - zy * zy + (type === 'julia' ? cx : zx0);
        zy = 2.0 * zx * zy + (type === 'julia' ? cy : zy0);
        zx = tmp;
        i--;
      }

      const pixelIndex = (x + y * width) * 4;
      const color = getColor(i, iterations, colorScheme);
      image.data[pixelIndex] = color.r;
      image.data[pixelIndex + 1] = color.g;
      image.data[pixelIndex + 2] = color.b;
      image.data[pixelIndex + 3] = 255;
    }
  }

  ctx.putImageData(image, 0, 0);
}

function getColor(i, max, scheme) {
  const t = i / max;
  switch (scheme) {
    case 'rainbow':
      return hslToRgb(t * 360, 1, 0.5);
    case 'grayscale':
      const g = Math.floor(t * 255);
      return { r: g, g: g, b: g };
    case 'blue':
      return { r: 0, g: 0, b: Math.floor(t * 255) };
    case 'fire':
      return {
        r: Math.floor(t * 255),
        g: Math.floor(t * 120),
        b: Math.floor(t * 60)
      };
    default:
      return { r: 0, g: 0, b: 0 };
  }
}

function hslToRgb(h, s, l) {
  h /= 360;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
}

function downloadFractal() {
  const canvas = document.getElementById('fractalCanvas');
  const link = document.createElement('a');
  link.download = 'fractal.png';
  link.href = canvas.toDataURL();
  link.click();
}

function startAnimation() {
  animZoom = 300;
  function animate() {
    document.getElementById('zoom').value = animZoom;
    generateFractal();
    animZoom += 10;
    if (animZoom < 1000) {
      animationId = requestAnimationFrame(animate);
    }
  }
  animate();
}

window.onload = generateFractal;
